let peds = [];
let currentCategory = 'all';
let renderToken = 0;
let searchTimer = null;
let lastFilterKey = '';

const app = document.getElementById('app');
const pedGrid = document.getElementById('pedGrid');
const categoryList = document.getElementById('categoryList');
const searchInput = document.getElementById('searchInput');
const serverName = document.getElementById('serverName');
const subtitle = document.getElementById('subtitle');
const avatar = document.getElementById('avatar');
const roleTag = document.getElementById('roleTag');
const profileName = document.getElementById('profileName');
const logoImg = document.getElementById('logoImg');
const discordFooter = document.getElementById('discordFooter');
const resetBtn = document.getElementById('resetBtn');
const settingsBtn = document.getElementById('settingsBtn');
const settingsPanel = document.getElementById('settingsPanel');
const settingsClose = document.getElementById('settingsClose');
const settingsTitle = document.getElementById('settingsTitle');
const settingsScaleLabel = document.getElementById('settingsScaleLabel');
const settingsAccentLabel = document.getElementById('settingsAccentLabel');
const settingsFxLabel = document.getElementById('settingsFxLabel');
const uiScaleRange = document.getElementById('uiScaleRange');
const uiScaleValue = document.getElementById('uiScaleValue');
const accentColorPicker = document.getElementById('accentColorPicker');
const accentColor = document.getElementById('accentColor');
const accentApply = document.getElementById('accentApply');
const fxToggle = document.getElementById('fxToggle');
const fxLayer = document.getElementById('fxLayer');

let pedCardImage = '';
let uiText = {};
const imageCache = new Map();
const FX_IMAGE = 'https://media.discordapp.net/attachments/1440657211213877382/1459659024164323582/Made_with_insMind-image_17.png?ex=696df826&is=696ca6a6&hm=8927a3ea8c19bf3381b7321f819dd53cc2b62e8f9b545f667baed32b1cbc07fc&=&format=webp&quality=lossless';
let fxEnabled = true;
let perfMode = false;

function setUiScale(value) {
    const scale = Math.max(50, Math.min(150, value));
    const ratio = scale / 100;
    document.documentElement.style.setProperty('--ui-scale', ratio.toString());
    if (uiScaleValue) uiScaleValue.textContent = `${scale}%`;
    localStorage.setItem('rxn_pedmenu_scale', scale.toString());
}

function setAccentColor(color) {
    const hex = color.startsWith('#') ? color : `#${color}`;
    const isValid = /^#[0-9A-Fa-f]{6}$/.test(hex);
    if (!isValid) return;
    document.documentElement.style.setProperty('--accent', hex);
    document.documentElement.style.setProperty('--accent-soft', `${hex}59`);
    localStorage.setItem('rxn_pedmenu_accent', hex);
    if (accentColor) accentColor.value = hex;
    if (accentColorPicker) accentColorPicker.value = hex;
}

function buildFxItems(count) {
    if (!fxLayer) return;
    fxLayer.innerHTML = '';
    for (let i = 0; i < count; i++) {
        const item = document.createElement('div');
        item.className = 'fx-item';
        const size = 16 + Math.random() * 20;
        const left = Math.random() * 100;
        const duration = 14 + Math.random() * 10;
        const delay = Math.random() * 6;
        item.style.width = `${size}px`;
        item.style.height = `${size}px`;
        item.style.left = `${left}%`;
        item.style.animationDuration = `${duration}s`;
        item.style.animationDelay = `${delay}s`;
        item.style.backgroundImage = `url('${FX_IMAGE}')`;
        fxLayer.appendChild(item);
    }
}

function setFxEnabled(state) {
    fxEnabled = state;
    localStorage.setItem('rxn_pedmenu_fx', state ? '1' : '0');
    if (!fxLayer) return;
    if (state) {
        fxLayer.classList.remove('hidden');
        if (!fxLayer.children.length) {
            buildFxItems(4);
        }
    } else {
        fxLayer.classList.add('hidden');
        fxLayer.innerHTML = '';
    }
}

function setPerformanceMode(state) {
    perfMode = state;
    localStorage.setItem('rxn_pedmenu_perf', state ? '1' : '0');
    app.classList.toggle('perf', !!state);
}

function loadUiSettings() {
    const savedScale = localStorage.getItem('rxn_pedmenu_scale');
    if (savedScale && uiScaleRange) {
        uiScaleRange.value = savedScale;
        setUiScale(parseInt(savedScale, 10));
    } else if (uiScaleRange) {
        setUiScale(parseInt(uiScaleRange.value, 10));
    }

    const savedAccent = localStorage.getItem('rxn_pedmenu_accent');
    if (savedAccent) {
        setAccentColor(savedAccent);
    }

    const savedFx = localStorage.getItem('rxn_pedmenu_fx');
    if (savedFx !== null) {
        setFxEnabled(savedFx === '1');
    } else {
        setFxEnabled(false);
    }
    if (fxToggle) fxToggle.checked = fxEnabled;

    const savedPerf = localStorage.getItem('rxn_pedmenu_perf');
    if (savedPerf !== null) {
        setPerformanceMode(savedPerf === '1');
    } else {
        setPerformanceMode(!fxEnabled);
    }
}

function setVisible(state) {
    if (state) {
        app.classList.remove('hidden');
        if (fxEnabled && fxLayer && !fxLayer.children.length) {
            buildFxItems(4);
        }
    } else {
        app.classList.add('hidden');
        if (fxLayer) {
            fxLayer.innerHTML = '';
        }
    }
}

function uniqueCategories(list) {
    const cats = new Set(['all']);
    list.forEach((item) => {
        if (item.category) cats.add(item.category);
    });
    return Array.from(cats);
}

function renderCategories() {
    categoryList.innerHTML = '';
    const cats = uniqueCategories(peds);
    cats.forEach((cat) => {
        const btn = document.createElement('button');
        btn.className = `category ${cat === currentCategory ? 'active' : ''}`;
        const allLabel = (uiText && uiText.categoriesAll) || 'Vše';
        btn.textContent = cat === 'all' ? allLabel : cat;
        btn.addEventListener('click', () => {
            currentCategory = cat;
            renderCategories();
            renderGrid();
        });
        categoryList.appendChild(btn);
    });
}

function renderGrid() {
    const searchValue = (searchInput.value || '').toLowerCase();
    const filterKey = `${currentCategory}|${searchValue}|${peds.length}`;
    if (filterKey === lastFilterKey) {
        return;
    }
    lastFilterKey = filterKey;
    const filtered = peds.filter((ped) => {
        const matchCategory = currentCategory === 'all' || ped.category === currentCategory;
        const matchSearch = ped.label.toLowerCase().includes(searchValue) || ped.model.toLowerCase().includes(searchValue);
        return matchCategory && matchSearch;
    });

    renderToken += 1;
    const myToken = renderToken;
    pedGrid.innerHTML = '';

    const BATCH_SIZE = 16;
    let i = 0;

    const renderBatch = () => {
        if (myToken !== renderToken) return;
        const frag = document.createDocumentFragment();
        const end = Math.min(i + BATCH_SIZE, filtered.length);
        for (; i < end; i++) {
            const ped = filtered[i];
            const card = document.createElement('div');
            card.className = 'card-item skeleton';
            const imgSrc = ped.image || pedCardImage || '';
            const thumb = document.createElement('div');
            thumb.className = 'thumb';
            const img = document.createElement('img');
            img.alt = 'ped';
            img.loading = 'lazy';
            img.decoding = 'async';
            thumb.appendChild(img);

            const label = document.createElement('div');
            label.className = 'label';
            label.textContent = ped.label;

            const model = document.createElement('div');
            model.className = 'model';
            model.textContent = ped.model;

            const category = document.createElement('div');
            category.className = 'category-pill';
            category.textContent = ped.category || 'Bez kategorie';

            card.appendChild(thumb);
            card.appendChild(label);
            card.appendChild(model);
            card.appendChild(category);

            if (imgSrc && imageCache.get(imgSrc) === 'loaded') {
                img.src = imgSrc;
                card.classList.remove('skeleton');
                card.classList.add('loaded');
            } else if (imgSrc) {
                img.onload = () => {
                    imageCache.set(imgSrc, 'loaded');
                    card.classList.remove('skeleton');
                    card.classList.add('loaded');
                };
                img.src = imgSrc;
            } else {
                card.classList.remove('skeleton');
                card.classList.add('loaded');
            }

            card.addEventListener('click', () => {
                fetch(`https://${GetParentResourceName()}/selectPed`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ model: ped.model })
                });
            });
            frag.appendChild(card);
        }
        pedGrid.appendChild(frag);
        if (i < filtered.length) {
            requestAnimationFrame(renderBatch);
        }
    };
    requestAnimationFrame(renderBatch);
}

function setRoleTag(role, label) {
    roleTag.className = `role-tag ${role || ''}`.trim();
    roleTag.textContent = label || '';
    app.classList.remove('owner', 'premium', 'streamer');
    if (role) {
        app.classList.add(role);
    }
}

function setProfileName(name, role) {
    profileName.textContent = name || 'Hráč';
    profileName.className = `profile-name ${role || ''}`.trim();
}

window.addEventListener('message', (event) => {
    const data = event.data;
    if (data.action === 'open') {
        peds = data.peds || [];
        currentCategory = 'all';
        serverName.textContent = data.serverName || 'RXN Roleplay';
        avatar.src = data.avatar || '';
        setRoleTag(data.role || '', data.roleLabel || '');
        setProfileName(data.playerName || 'Hráč', data.role || '');
        pedCardImage = data.pedCardImage || '';
        uiText = data.uiText || {};
        if (subtitle) subtitle.textContent = uiText.subtitle || 'Ped VIP Menu';
        if (searchInput) searchInput.placeholder = uiText.searchPlaceholder || 'Hledej peda...';
        if (resetBtn) resetBtn.textContent = uiText.resetButton || 'Vrátit původního';
        if (discordFooter) discordFooter.textContent = uiText.discordFooter || 'discord.gg/eclipsegg';
        if (settingsTitle) settingsTitle.textContent = uiText.settingsTitle || 'Settings';
        if (settingsScaleLabel) settingsScaleLabel.textContent = uiText.settingsScale || 'Velikost UI';
        if (settingsAccentLabel) settingsAccentLabel.textContent = uiText.settingsAccent || 'Accent barva';
        if (settingsFxLabel) settingsFxLabel.textContent = uiText.settingsFx || 'Pozadí efekt';
        if (data.logo) {
            logoImg.src = data.logo;
        }
        if (settingsPanel) {
            settingsPanel.classList.add('hidden');
        }
        renderCategories();
        renderGrid();
        loadUiSettings();
        setVisible(true);
    }

    if (data.action === 'close') {
        if (settingsPanel) {
            settingsPanel.classList.add('hidden');
        }
        setVisible(false);
    }
});

document.getElementById('closeBtn').addEventListener('click', () => {
    fetch(`https://${GetParentResourceName()}/close`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({})
    });
});

if (settingsBtn && settingsPanel) {
    settingsBtn.addEventListener('click', () => {
        settingsPanel.classList.toggle('hidden');
    });
}

if (settingsClose && settingsPanel) {
    settingsClose.addEventListener('click', () => {
        settingsPanel.classList.add('hidden');
    });
}

if (uiScaleRange) {
    uiScaleRange.addEventListener('input', (e) => {
        setUiScale(parseInt(e.target.value, 10));
    });
}

if (accentApply && accentColor) {
    accentApply.addEventListener('click', () => {
        setAccentColor(accentColor.value.trim());
    });
}

if (accentColorPicker) {
    accentColorPicker.addEventListener('input', (e) => {
        setAccentColor(e.target.value);
    });
}

if (fxToggle) {
    fxToggle.addEventListener('change', (e) => {
        const enabled = !!e.target.checked;
        setFxEnabled(enabled);
        setPerformanceMode(!enabled);
    });
}

document.getElementById('resetBtn').addEventListener('click', () => {
    fetch(`https://${GetParentResourceName()}/resetPed`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({})
    });
});

searchInput.addEventListener('input', () => {
    if (searchTimer) {
        clearTimeout(searchTimer);
    }
    searchTimer = setTimeout(() => {
        renderGrid();
    }, 120);
});
