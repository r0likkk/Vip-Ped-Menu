local uiOpen = false
local originalModel = nil
local lastLockCheckAt = 0

-- Helper function to get localized text
local function T(key)
    return Locales[Config.Locale] and Locales[Config.Locale][key] or key
end

local function Notify(title, description, ntype)
    lib.notify({
        title = title,
        description = description,
        type = ntype or 'inform'
    })
end

local function GetAvatarUrl(discordId, avatarHash)
    if discordId and avatarHash and avatarHash ~= '' then
        return ("https://cdn.discordapp.com/avatars/%s/%s.png?size=128"):format(discordId, avatarHash)
    end
    return Config.UI.DefaultAvatar
end

local function GetLocaleText()
    local locale = Config.Locale or 'cs'
    local pack = Locales and Locales[locale] or nil
    if pack then
        return pack
    end
    return {
        subtitle = 'Ped VIP Menu',
        searchPlaceholder = 'Hledej peda...',
        resetButton = 'Vrátit původního',
        discordFooter = 'discord.gg/eclipsegg',
        categoriesAll = 'Vše'
    }
end

local function OpenUi()
    if uiOpen then return end
    uiOpen = true

    if not originalModel then
        originalModel = GetEntityModel(PlayerPedId())
    end

    local data = lib.callback.await('rxn_pedmenu:getData', false)
    if not data or not data.player then
        Notify('Ped VIP', T('NO_ACCESS'), 'error')
        uiOpen = false
        return
    end

    if data.locked then
        Notify('Ped VIP', T('LOCKED_ACTION'), 'error')
        uiOpen = false
        return
    end

    if not data.player.discordId then
        Notify('Ped VIP', T('NOT_LINKED'), 'error')
        uiOpen = false
        return
    end

    if #data.peds == 0 then
        Notify('Ped VIP', T('NO_ACCESS'), 'error')
        uiOpen = false
        return
    end

    local avatarUrl = GetAvatarUrl(data.player.discordId, data.player.avatarHash)

    SetNuiFocus(true, true)
    SendNUIMessage({
        action = 'open',
        serverName = data.serverName,
        role = data.player.primaryRole,
        roleLabel = data.player.roleLabel,
        avatar = avatarUrl,
        peds = data.peds,
        playerName = data.player.playerName,
        logo = Config.UI.LogoUrl,
        pedCardImage = Config.UI.PedCardImage,
        uiText = GetLocaleText()
    })

    Notify('Ped VIP', T('UI_OPENED'), 'inform')
end

local function CloseUi()
    if not uiOpen then return end
    uiOpen = false
    SetNuiFocus(false, false)
    SendNUIMessage({ action = 'close' })
    Notify('Ped VIP', T('UI_CLOSED'), 'inform')
end

local function SetPlayerModelSafe(model, opts)
    local modelHash = type(model) == 'number' and model or joaat(model)
    if not IsModelInCdimage(modelHash) or not IsModelValid(modelHash) then
        Notify('Ped VIP', T('INVALID_MODEL'), 'error')
        return
    end

    if not opts or opts.loadingNotify ~= false then
        Notify('Ped VIP', T('MODEL_LOADING'), 'inform')
    end
    RequestModel(modelHash)
    while not HasModelLoaded(modelHash) do
        Wait(0)
    end

    SetPlayerModel(PlayerId(), modelHash)
    SetModelAsNoLongerNeeded(modelHash)
    SetPedDefaultComponentVariation(PlayerPedId())
    if not opts or opts.successNotify ~= false then
        Notify('Ped VIP', T('MODEL_SET'), 'success')
    end
end

RegisterNUICallback('close', function(_, cb)
    CloseUi()
    cb('ok')
end)

RegisterNUICallback('selectPed', function(data, cb)
    if data and data.model then
        TriggerServerEvent('rxn_pedmenu:selectPed', data.model)
    end
    cb('ok')
end)

RegisterNUICallback('resetPed', function(_, cb)
    TriggerServerEvent('rxn_pedmenu:resetPed')
    cb('ok')
end)

RegisterNetEvent('rxn_pedmenu:applyPed', function(model)
    CloseUi()
    SetPlayerModelSafe(model)
end)

RegisterNetEvent('rxn_pedmenu:resetPed', function()
    if originalModel then
        CloseUi()
        SetPlayerModelSafe(originalModel, { successNotify = false })
        Notify('Ped VIP', T('MODEL_RESET'), 'success')
    end
end)

RegisterCommand(Config.Command, function()
    OpenUi()
end, false)

RegisterKeyMapping(Config.Command, Config.CommandDescription, 'keyboard', Config.Keybind or '')

local function CheckAndApplyLock()
    local now = GetGameTimer()
    if now - lastLockCheckAt < 3000 then return end
    lastLockCheckAt = now

    local lockData = lib.callback.await('rxn_pedmenu:getLock', false)
    if lockData and lockData.locked and lockData.model then
        SetPlayerModelSafe(lockData.model, { loadingNotify = false, successNotify = false })
    end
end

AddEventHandler('playerSpawned', function()
    Wait(1500)
    CheckAndApplyLock()
end)

AddEventHandler('onClientResourceStart', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    Wait(1500)
    CheckAndApplyLock()
end)
