
Secret = {}

-- Discord Bot Configuration
Secret.Discord = {
    BotToken = 'YOUR_BOT_TOKEN_HERE',
    GuildId = 'YOUR_GUILD_ID_HERE',
    RoleIds = {
        owner = { '1452045575594967151' },
        premium = { '1452045614975025360' },
        streamer = { '1452045614287290498' }
    },
    RolePriority = {
        owner = 1,
        premium = 2,
        streamer = 3,
        player = 99
    },
    RoleLabels = {
        owner = 'OWNER',
        premium = 'PREMIUM',
        streamer = 'STREAMER',
        player = 'HRÁČ'
    }
}

Secret.Logs = {
    Enabled = true,
    Webhooks = {
        open = 'YOUR_OPEN_WEBHOOK_URL_HERE',
        select = 'YOUR_SELECT_WEBHOOK_URL_HERE',
        reset = 'YOUR_RESET_WEBHOOK_URL_HERE',
        locked = 'YOUR_LOCKED_WEBHOOK_URL_HERE',
        vehicle = 'YOUR_VEHICLE_WEBHOOK_URL_HERE'
    },
    Color = 5793266,
    Title = 'Ped VIP Log',
    Footer = 'Eclipse Roleplay',
    Thumbnail = '',
    Image = ''
}
