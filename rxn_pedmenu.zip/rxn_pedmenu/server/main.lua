print('^2[rxn_pedmenu] ^7Ped VIP Menu loaded successfully.')
print('^2[rxn_pedmenu] ^7If you need anything feel free to ask me here: ^3https://rolikk.space/^7')
print('')


local function T(key)
    return Locales[Config.Locale] and Locales[Config.Locale][key] or key
end

local function Notify(source, title, description, ntype)
    TriggerClientEvent('ox_lib:notify', source, {
        title = title,
        description = description,
        type = ntype or 'inform'
    })
end

local SendWebhook

local function GetWebhook(key)
    if not Secret.Logs or not Secret.Logs.Webhooks then
        return nil
    end
    return Secret.Logs.Webhooks[key]
end

SendWebhook = function(key, message, extra)
    if not Secret.Logs or not Secret.Logs.Enabled then
        return
    end

    local webhook = GetWebhook(key)
    if not webhook or webhook == '' then
        return
    end

    local embed = {
        title = Secret.Logs.Title or 'Ped VIP Log',
        description = message,
        color = Secret.Logs.Color or 5793266,
        fields = extra or {},
        footer = { text = (Secret.Logs.Footer or 'Eclipse Roleplay') .. ' • ' .. os.date('%d.%m.%Y %H:%M:%S') }
    }

    if Secret.Logs.Thumbnail and Secret.Logs.Thumbnail ~= '' then
        embed.thumbnail = { url = Secret.Logs.Thumbnail }
    end
    if Secret.Logs.Image and Secret.Logs.Image ~= '' then
        embed.image = { url = Secret.Logs.Image }
    end

    PerformHttpRequest(webhook, function() end, 'POST', json.encode({
        username = 'RXN PedMenu',
        embeds = { embed }
    }), { ['Content-Type'] = 'application/json' })
end

local function LoadLocks()
    local raw = LoadResourceFile(GetCurrentResourceName(), Config.Locking and Config.Locking.DataFile or 'data/locks.json')
    if not raw or raw == '' then
        return {}
    end
    local ok, parsed = pcall(json.decode, raw)
    if ok and type(parsed) == 'table' then
        return parsed
    end
    return {}
end

local function SaveLocks(locks)
    SaveResourceFile(GetCurrentResourceName(), Config.Locking and Config.Locking.DataFile or 'data/locks.json', json.encode(locks, { indent = true }), -1)
end

local locks = LoadLocks()

local function BuildRoleMap()
    local roleMap = {}
    for roleName, ids in pairs(Secret.Discord.RoleIds or {}) do
        for _, id in ipairs(ids) do
            roleMap[id] = roleName
        end
    end
    return roleMap
end

local roleMap = BuildRoleMap()

local function GetPrimaryRole(mappedRoles)
    local bestRole = 'player'
    local bestPriority = (Secret.Discord.RolePriority and Secret.Discord.RolePriority.player) or 99

    for _, roleName in ipairs(mappedRoles) do
        local pr = Secret.Discord.RolePriority and Secret.Discord.RolePriority[roleName] or nil
        if pr and pr < bestPriority then
            bestPriority = pr
            bestRole = roleName
        end
    end

    return bestRole
end

local function RolesFromDiscordIds(roles)
    local mapped = {}
    for _, roleId in ipairs(roles or {}) do
        local name = roleMap[roleId]
        if name then
            table.insert(mapped, name)
        end
    end
    return mapped
end

local function IsModelAllowed(model, allowed)
    local target = string.lower(model)
    for _, ped in ipairs(allowed) do
        if string.lower(ped.model) == target then
            return true
        end
    end
    return false
end

local function GetPlayerIdentifier(source)
    for _, identifier in ipairs(GetPlayerIdentifiers(source)) do
        if string.sub(identifier, 1, 8) == 'license:' then
            return identifier
        end
    end
    return GetPlayerIdentifiers(source)[1]
end

local function GetLockForSource(source)
    if not Config.Locking or not Config.Locking.Enabled then
        return nil
    end
    local identifier = GetPlayerIdentifier(source)
    if not identifier then return nil end
    return locks[identifier]
end

local function SetLockForSource(source, data)
    if not Config.Locking or not Config.Locking.Enabled then
        return
    end
    local identifier = GetPlayerIdentifier(source)
    if not identifier then return end
    locks[identifier] = data
    SaveLocks(locks)
end

local function FindPedByModel(model)
    local target = string.lower(model)
    for _, ped in ipairs(Config.Peds or {}) do
        if string.lower(ped.model) == target then
            return ped
        end
    end
    return nil
end

local function GeneratePlate(prefix)
    local base = tostring(math.random(1000, 9999))
    local p = (prefix or 'VIP'):upper()
    if #p > 4 then
        p = string.sub(p, 1, 4)
    end
    return (p .. base)
end

local function GrantVehicle(source, model)
    if not Config.VehicleGrant or not Config.VehicleGrant.Enabled then
        return false
    end
    if GetResourceState('oxmysql') ~= 'started' then
        return false
    end

    local identifier = GetPlayerIdentifier(source)
    if not identifier then return false end

    local plate = GeneratePlate(Config.VehicleGrant.PlatePrefix)
    local props = {
        model = joaat(model),
        plate = plate
    }

    local insertData = {
        [Config.VehicleGrant.OwnerField] = identifier,
        [Config.VehicleGrant.PlateField] = plate,
        [Config.VehicleGrant.VehicleField] = json.encode(props),
        [Config.VehicleGrant.TypeField] = Config.VehicleGrant.GarageType or 'car'
    }

    local columns = {}
    local values = {}
    local placeholders = {}
    for k, v in pairs(insertData) do
        table.insert(columns, k)
        table.insert(values, v)
        table.insert(placeholders, '?')
    end

    local query = ('INSERT INTO %s (%s) VALUES (%s)'):format(
        Config.VehicleGrant.Table,
        table.concat(columns, ','),
        table.concat(placeholders, ',')
    )

    local ok = pcall(function()
        exports.oxmysql:insert(query, values)
    end)

    return ok
end

local function BuildAllowedPeds(primaryRole, mappedRoles)
    local allowDefault = Config.Access and Config.Access.AllowDefault
    local maxPeds = Config.Access and Config.Access.MaxPeds and Config.Access.MaxPeds[primaryRole] or nil
    local allowed = {}

    for _, ped in ipairs(Config.Peds or {}) do
        local roles = ped.roles or {}
        local isDefault = #roles == 0
        local ok = false

        if isDefault then
            ok = allowDefault
        else
            for _, role in ipairs(roles) do
                for _, owned in ipairs(mappedRoles) do
                    if role == owned then
                        ok = true
                        break
                    end
                end
                if ok then break end
            end
        end

        if ok then
            table.insert(allowed, ped)
        end
    end

    if maxPeds and maxPeds > 0 and #allowed > maxPeds then
        local trimmed = {}
        for i = 1, maxPeds do
            trimmed[i] = allowed[i]
        end
        return trimmed
    end

    if maxPeds == 0 then
        return {}
    end

    return allowed
end

local function GetDiscordId(source)
    return exports.rxn_pedmenu:getDiscordId(source)
end

local function GetDiscordRolesAndAvatar(source, cb)
    return exports.rxn_pedmenu:getDiscordRolesAndAvatar(source, cb)
end

local function BuildPlayerData(source, cb)
    local discordId = GetDiscordId(source)
    local playerName = GetPlayerName(source)
    if not discordId then
        cb({
            discordId = nil,
            avatarHash = nil,
            roles = {},
            primaryRole = 'player',
            roleLabel = Secret.Discord.RoleLabels.player or 'HRÁČ',
            playerName = playerName
        })
        return
    end

    GetDiscordRolesAndAvatar(source, function(roles, avatarHash)
        local mappedRoles = RolesFromDiscordIds(roles or {})
        local primaryRole = GetPrimaryRole(mappedRoles)
        local roleLabel = (Secret.Discord.RoleLabels and Secret.Discord.RoleLabels[primaryRole]) or primaryRole

        cb({
            discordId = discordId,
            avatarHash = avatarHash,
            roles = mappedRoles,
            primaryRole = primaryRole,
            roleLabel = roleLabel,
            playerName = playerName
        })
    end)
end

local function BuildAccessForPlayer(source, cb)
    BuildPlayerData(source, function(playerData)
        local allowed = BuildAllowedPeds(playerData.primaryRole, playerData.roles)
        cb(playerData, allowed)
    end)
end

lib.callback.register('rxn_pedmenu:getData', function(source)
    local p = promise.new()
    BuildAccessForPlayer(source, function(playerData, allowed)
        local lockData = GetLockForSource(source)
        SendWebhook('open', 'Hráč otevřel Ped VIP menu.', {
            { name = 'Hráč', value = ("%s (%s)"):format(GetPlayerName(source) or 'Unknown', source), inline = true },
            { name = 'Role', value = playerData.primaryRole, inline = true },
            { name = 'Discord', value = playerData.discordId or 'N/A', inline = true }
        })
        p:resolve({
            player = playerData,
            peds = allowed,
            serverName = Config.UI.ServerName,
            locked = lockData ~= nil,
            lockedModel = lockData and lockData.model or nil
        })
    end)
    return Citizen.Await(p)
end)

lib.callback.register('rxn_pedmenu:getLock', function(source)
    local lockData = GetLockForSource(source)
    if not lockData then
        return { locked = false }
    end
    return { locked = true, model = lockData.model }
end)

RegisterNetEvent('rxn_pedmenu:selectPed', function(model)
    local src = source
    if not model or model == '' then return end

    local locked = GetLockForSource(src)
    if locked then
        Notify(src, 'Ped VIP', T('LOCKED_ACTION'), 'error')
        SendWebhook('locked', 'Hráč se pokusil použít menu, ale má zamčeného peda.', {
            { name = 'Hráč', value = ("%s (%s)"):format(GetPlayerName(src) or 'Unknown', src), inline = true },
            { name = 'Locked Ped', value = locked.model or 'N/A', inline = true }
        })
        return
    end

    BuildAccessForPlayer(src, function(playerData, allowed)
        if #allowed == 0 then
            Notify(src, 'Ped VIP', T('NO_ACCESS'), 'error')
            return
        end

        if not IsModelAllowed(model, allowed) then
            Notify(src, 'Ped VIP', T('NOT_ALLOWED'), 'error')
            return
        end

        local pedCfg = FindPedByModel(model)
        if pedCfg and pedCfg.lock and Config.Locking and Config.Locking.Enabled then
            SetLockForSource(src, { model = model, lockedAt = os.time() })
        end

        TriggerClientEvent('rxn_pedmenu:applyPed', src, model)

        if pedCfg and pedCfg.lock then
            Notify(src, 'Ped VIP', T('LOCKED_PED'), 'inform')
            local vehicleModel = pedCfg.grantVehicle and pedCfg.grantVehicle.model or (Config.VehicleGrant and Config.VehicleGrant.Model)
            if vehicleModel and GrantVehicle(src, vehicleModel) then
                Notify(src, 'Ped VIP', T('VEHICLE_GRANTED'), 'success')
                SendWebhook('vehicle', 'Hráči bylo přidáno vozidlo.', {
                    { name = 'Hráč', value = ("%s (%s)"):format(GetPlayerName(src) or 'Unknown', src), inline = true },
                    { name = 'Vozidlo', value = vehicleModel, inline = true }
                })
            end
        end

        local fields = {
            { name = 'Hráč', value = ("%s (%s)"):format(GetPlayerName(src) or 'Unknown', src), inline = true },
            { name = 'Role', value = playerData.primaryRole, inline = true },
            { name = 'Discord', value = playerData.discordId or 'N/A', inline = true },
            { name = 'Ped', value = model, inline = false }
        }
        SendWebhook('select', 'Hráč změnil peda.', fields)
    end)
end)

RegisterNetEvent('rxn_pedmenu:resetPed', function()
    local src = source
    local locked = GetLockForSource(src)
    if locked then
        Notify(src, 'Ped VIP', T('LOCKED_ACTION'), 'error')
        SendWebhook('locked', 'Hráč se pokusil resetovat ped, ale má zamčeného peda.', {
            { name = 'Hráč', value = ("%s (%s)"):format(GetPlayerName(src) or 'Unknown', src), inline = true },
            { name = 'Locked Ped', value = locked.model or 'N/A', inline = true }
        })
        return
    end
    BuildPlayerData(src, function(playerData)
        TriggerClientEvent('rxn_pedmenu:resetPed', src)

        local fields = {
            { name = 'Hráč', value = ("%s (%s)"):format(GetPlayerName(src) or 'Unknown', src), inline = true },
            { name = 'Role', value = playerData.primaryRole, inline = true },
            { name = 'Discord', value = playerData.discordId or 'N/A', inline = true }
        }
        SendWebhook('reset', 'Hráč vrátil původního peda.', fields)
    end)
end)
