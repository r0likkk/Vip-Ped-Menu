local function LoadSecrets()
    local raw = LoadResourceFile(GetCurrentResourceName(), 'secrets.json')
    if not raw or raw == '' then
        return {}
    end

    local ok, parsed = pcall(json.decode, raw)
    if ok and type(parsed) == 'table' then
        return parsed
    end

    return {}
end

local secrets = LoadSecrets()

local function GetSettingString(secretKey, convarName, defaultValue)
    local v = GetConvar(convarName, '')
    if v ~= '' then
        return v
    end

    local s = secrets[secretKey]
    if type(s) == 'string' and s ~= '' then
        return s
    end

    return defaultValue
end

local DISCORD_BOT_TOKEN = GetSettingString('discord_bot_token', 'pedmenu_discord_bot_token', Config.Discord.BotToken or '')
local DISCORD_GUILD_ID = GetSettingString('discord_guild_id', 'pedmenu_discord_guild_id', Config.Discord.GuildId or '')

local discordMemberCache = {}
local DISCORD_CACHE_TTL_MS = 60 * 1000

local discordFetchQueue = {}
local discordFetchPending = {}
local DISCORD_FETCH_INTERVAL_MS = 350

local function NowMs()
    if type(GetGameTimer) == 'function' then
        return GetGameTimer()
    end
    return os.time() * 1000
end

local function GetDiscordIdFromPlayerIdentifiers(playerId)
    for _, identifier in ipairs(GetPlayerIdentifiers(playerId)) do
        if string.sub(identifier, 1, 8) == 'discord:' then
            return string.sub(identifier, 9)
        end
    end
    return nil
end

local function ExtractRolesAndAvatar(member)
    local roles = {}
    local avatarHash = nil

    if member then
        if member.roles then
            roles = member.roles
        end
        if member.user and member.user.avatar then
            avatarHash = member.user.avatar
        end
    end

    return roles, avatarHash
end

local function GetCachedDiscordData(discordId)
    local cached = discordMemberCache[discordId]
    if cached and cached.ts and (NowMs() - cached.ts) < DISCORD_CACHE_TTL_MS then
        local roles, avatarHash = ExtractRolesAndAvatar(cached.member)
        return roles, avatarHash
    end
    return nil, nil
end

local function EnqueueDiscordFetch(discordId)
    if DISCORD_BOT_TOKEN == '' or DISCORD_GUILD_ID == '' then
        return false
    end

    if discordFetchPending[discordId] then
        return false
    end

    discordFetchPending[discordId] = true
    table.insert(discordFetchQueue, discordId)
    return true
end

CreateThread(function()
    while true do
        if #discordFetchQueue == 0 then
            Wait(500)
        else
            local discordId = table.remove(discordFetchQueue, 1)
            if discordId then
                local endpoint = ("https://discord.com/api/guilds/%s/members/%s"):format(DISCORD_GUILD_ID, discordId)
                PerformHttpRequest(endpoint, function(statusCode, data)
                    discordFetchPending[discordId] = nil
                    if statusCode == 200 and data then
                        local member = json.decode(data)
                        if member then
                            discordMemberCache[discordId] = { ts = NowMs(), member = member }
                        end
                    end
                end, 'GET', '', {
                    ['Authorization'] = 'Bot ' .. DISCORD_BOT_TOKEN,
                    ['Content-Type'] = 'application/json'
                })
            end

            Wait(DISCORD_FETCH_INTERVAL_MS)
        end
    end
end)

local function GetDiscordRolesAndAvatar(discordId, cb)
    if DISCORD_BOT_TOKEN == '' or DISCORD_GUILD_ID == '' then
        cb({}, nil, false)
        return
    end

    local cached = discordMemberCache[discordId]
    if cached and cached.ts and (NowMs() - cached.ts) < DISCORD_CACHE_TTL_MS then
        local roles, avatarHash = ExtractRolesAndAvatar(cached.member)
        cb(roles, avatarHash, true)
        return
    end

    EnqueueDiscordFetch(discordId)

    local deadline = NowMs() + 2000
    local function poll()
        local cached2 = discordMemberCache[discordId]
        if cached2 and cached2.ts and (NowMs() - cached2.ts) < DISCORD_CACHE_TTL_MS then
            local roles, avatarHash = ExtractRolesAndAvatar(cached2.member)
            cb(roles, avatarHash, true)
            return
        end

        if NowMs() >= deadline then
            cb({}, nil, false)
            return
        end

        SetTimeout(200, poll)
    end

    SetTimeout(0, poll)
end

exports('getDiscordId', function(playerId)
    if not playerId then return nil end
    return GetDiscordIdFromPlayerIdentifiers(playerId)
end)

exports('getDiscordRolesAndAvatar', function(playerId, cb)
    if not playerId then
        cb({}, nil, false)
        return
    end
    local discordId = GetDiscordIdFromPlayerIdentifiers(playerId)
    if not discordId then
        cb({}, nil, false)
        return
    end
    GetDiscordRolesAndAvatar(discordId, cb)
end)

exports('getDiscordRolesAndAvatarById', function(discordId, cb)
    if not discordId then
        cb({}, nil, false)
        return
    end
    GetDiscordRolesAndAvatar(discordId, cb)
end)
