Locales['en'] = {
    -- UI Text
    subtitle = 'Ped VIP Menu',
    searchPlaceholder = 'Search ped...',
    resetButton = 'Reset to original',
    discordFooter = 'discord.gg/eclipsegg',
    categoriesAll = 'All',
    noResults = 'No results found',
    settingsTitle = 'Settings',
    settingsScale = 'UI size',
    settingsAccent = 'Accent color',
    settingsFx = 'Background effect',

    -- Notifications
    NO_ACCESS = 'You have no access to any peds.',
    INVALID_MODEL = 'This ped does not exist.',
    MODEL_LOADING = 'Loading ped...',
    MODEL_SET = 'Ped has been changed.',
    MODEL_RESET = 'Ped has been reset.',
    LOCKED_PED = 'Your ped is locked to this character.',
    LOCKED_ACTION = 'Ped menu is locked for this character.',
    VEHICLE_GRANTED = 'Vehicle has been added to garage.',
    NOT_LINKED = 'You do not have a linked Discord account.',
    NOT_ALLOWED = 'You do not have permission for this ped.',
    UI_OPENED = 'Ped menu opened.',
    UI_CLOSED = 'Ped menu closed.'
}
