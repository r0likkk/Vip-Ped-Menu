Locales['cs'] = {
    -- UI Text
    subtitle = 'Ped VIP Menu',
    searchPlaceholder = 'Hledej peda...',
    resetButton = 'Vrátit původního',
    discordFooter = 'discord.gg/eclipsegg',
    categoriesAll = 'Vše',
    noResults = 'Nic nenalezeno',
    settingsTitle = 'Nastavení',
    settingsScale = 'Velikost UI',
    settingsAccent = 'Accent barva',
    settingsFx = 'Pozadí efekt',

    -- Notifications
    NO_ACCESS = 'Nemáš přístup k žádným pedům.',
    INVALID_MODEL = 'Tento ped neexistuje.',
    MODEL_LOADING = 'Načítám peda...',
    MODEL_SET = 'Ped byl změněn.',
    MODEL_RESET = 'Ped byl vrácen.',
    LOCKED_PED = 'Tvůj ped je uzamčený na této postavě.',
    LOCKED_ACTION = 'Ped menu je uzamčené pro tuto postavu.',
    VEHICLE_GRANTED = 'Auto bylo přidáno do garáže.',
    NOT_LINKED = 'Nemáš propojený Discord účet.',
    NOT_ALLOWED = 'Nemáš oprávnění na tohoto peda.',
    UI_OPENED = 'Ped menu otevřeno.',
    UI_CLOSED = 'Ped menu zavřeno.'
}
