Config = {}

Config.Command = 'pedmenu'
Config.CommandDescription = 'Otevřít Ped VIP menu'
Config.Keybind = 'F9'

Config.UI = {
    ServerName = 'rolikk',
    LogoUrl = '',
    PedCardImage = '',
    DefaultAvatar = ''
}

Config.Locale = 'cs'

Config.Locking = {
    Enabled = true,
    DataFile = 'data/locks.json'
}

Config.VehicleGrant = {
    Enabled = true,
    Model = 'sultan',
    PlatePrefix = 'ECL',
    GarageType = 'car',
    Table = 'owned_vehicles',
    OwnerField = 'owner',
    PlateField = 'plate',
    VehicleField = 'vehicle',
    TypeField = 'type'
}

Config.Access = {
    AllowDefault = false,
    MaxPeds = {
        owner = 50,
        premium = 4,
        streamer = 2,
        player = 0
    }
}

Config.Peds = {
    {
        label = 'Michael',
        model = 'player_zero',
        roles = { 'premium', 'streamer', 'owner' },
        category = 'Classic',
        image = ''
    },
    {
        label = 'Franklin',
        model = 'player_one',
        roles = { 'premium', 'streamer', 'owner' },
        category = 'Classic',
        image = ''
    },
    {
        label = 'Trevor',
        model = 'player_two',
        roles = { 'premium', 'streamer', 'owner' },
        category = 'Classic',
        image = ''
    },
    {
        label = 'Díte Henry',
        model = 'pw_hendry',
        roles = { 'premium', 'owner' },
        category = 'Classic',
        image = ''
    },
    {
        label = 'Díte Diyo',
        model = 'pw_diyo',
        roles = { 'streamer', 'premium', 'owner' },
        category = 'Classic',
        image = ''
    },
    {
        label = 'K-9 Police',
        model = 'a_c_shepherd',
        roles = { 'premium', 'owner' },
        category = 'Special',
        image = ''
    },
    {
        label = 'KG-03',
        model = 'kg03',
        roles = { 'streamer', 'premium', 'owner' },
        category = 'Fun',
        image = ''
    },
    {
        label = 'Díte',
        model = 'Child',
        roles = { 'streamer', 'premium', 'owner' },
        category = 'Fun',
        image = ''
    },
    {
        label = 'Díte Victoria',
        model = 'Melody_Victoria',
        roles = { 'premium', 'owner' },
        category = 'Uniform',
        image = ''
    },
    {
        label = 'Díte Amiri',
        model = 'Melody_Amiri',
        roles = { 'owner' },
        category = 'Uniform',
        image = '',
        lock = true,
        grantVehicle = { model = 'baller7' }
    }
    ,
    {
        label = 'P1 Cop',
        model = 'P1_cop',
        roles = { 'owner', 'premium', 'streamer' },
        category = 'Uniform',
        image = 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQtJOtI_kUkwR-v84FFNePMwLtihe649IB5GA&s'
    }
}

