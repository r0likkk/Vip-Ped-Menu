fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'RXN Ped VIP Menu'
version '1.0.0'
author 'rxn'

ui_page 'html/pedmenu.html'

files {
    'html/pedmenu.html',
    'html/pedmenu.css',
    'html/pedmenu.js'
}

shared_scripts {
    '@ox_lib/init.lua',
    'locales/cs.lua',
    'locales/en.lua',
    'sh_config.lua'
}

client_scripts {
    'client/main.lua'
}

server_scripts {
    'server/secret.lua',
    'server/discord.lua',
    'server/main.lua'
}

dependencies {
    'ox_lib'
}
